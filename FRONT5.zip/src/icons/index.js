export { default as callIcon } from './callIcon.svg'
export { default as emailIcon } from './emailIcon.svg'
export { default as headIcon } from './headIcon.svg'
export { default as arrowUp } from './arrowUp.svg'
export { default as arrowBottom } from './arrowBottom.svg'
export { default as dashboard } from './dashboard.svg'
export { default as productsIcon } from './productsIcon.svg'
export { default as logo } from './logo.svg'
export { default as settings } from './settings.svg'
export { default as notification } from './notification.svg'
export { default as sales } from './sales.svg'
export { default as expandIcon } from './expandIcon.svg'
export { default as linkIcon } from './linkIcon.svg'
export { default as deleteIcon } from './deleteIcon.svg'
export { default as viewIcon } from './viewIcon.svg'
export { default as correctSign } from './correctSign.svg'
export { default as close } from './close.svg'
export { default as pdfIcon } from './pdfIcon.svg'
export { default as downloadIcon } from './downloadIcon.svg'




