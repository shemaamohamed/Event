export { default as arrowIcon } from "./arrowIcon.svg";
